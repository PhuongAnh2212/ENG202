#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import random
import time

class ObjectAvoidanceNode(Node):
    def __init__(self):
        super().__init__('object_avoidance_node')
        self.subscription = self.create_subscription(
            LaserScan,
            'scan',
            self.lidar_callback,
            10)
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.safe_distance = 1.0  # Meters
        self.state = 'dithang'  # Initial state
        self.rotation_start_time = None
        self.random_angle = 0.0
        self.get_logger().info('Object Avoidance Node Started')
        
    def lidar_callback(self, msg):
        ranges = msg.ranges
        angle_min = msg.angle_min
        angle_increment = msg.angle_increment
        range_distance_middle_angle = ranges[len(ranges) // 2]

        print("Start angle of the scan:", angle_min)
        print("Angular distance between measurements:", angle_increment)
        print("Range distance of the middle angle:", range_distance_middle_angle)

        min_distance = min(ranges)
        print("Minimum distance detected:", min_distance)

        twist_msg = Twist()
        
        if self.state == 'dunglaidiiiii':
            if min_distance < self.safe_distance:
                twist_msg.linear.x = 0.0
                twist_msg.angular.z = 0.0
                self.publisher.publish(twist_msg)
                self.get_logger().info('Obstacle detected! Stopping.')

                self.state = 'xoay'
                self.rotation_start_time = time.time()
                self.random_angle = random.uniform(-1.0, 1.0)
                self.publisher.publish(twist_msg)
                self.get_logger().info(f'Rotating to random angle: {self.random_angle}')

        elif self.state == 'xoay':
            twist_msg.linear.x = 0.0
            twist_msg.angular.z = self.random_angle
            self.publisher.publish(twist_msg)

            if time.time() - self.rotation_start_time > 1.5:
                twist_msg.angular.z = 0.0
                self.publisher.publish(twist_msg)
                self.state = 'dithang'
                self.get_logger().info('Rotation complete. Moving forward.')

        elif self.state == 'dithang':
            if min_distance >= self.safe_distance:

                twist_msg.linear.x = 0.2
                twist_msg.angular.z = 0.0
                self.publisher.publish(twist_msg)
            else:
                self.state = 'dunglaidiiiii'
                self.get_logger().info('Obstacle detected again! Stopping.')

def main(args=None):
    rclpy.init(args=args)
    node = ObjectAvoidanceNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Keyboard Interrupt (SIGINT)')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()